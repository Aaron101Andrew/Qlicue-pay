# qlicue-pay
Africa's leading payment gateway by 2025
